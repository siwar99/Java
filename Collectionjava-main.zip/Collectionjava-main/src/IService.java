public interface IService <T>{

    void  add(T t) ;
    void  supprime (T t) ;



}
