public class Service implements IService<Pesrsonne> {

    @Override
    public void add(Pesrsonne pesrsonne) {

    }
    @Override
    public void supprime(Pesrsonne pesrsonne) {

    }
}

